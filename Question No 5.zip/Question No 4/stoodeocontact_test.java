package Assignment;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class stoodeocontact_test {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Installer\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.manage().window().maximize();
		driver.get("https://www.stoodeo.com/");
		
		stoodeocontact test = new stoodeocontact(driver);
		
		test.contact();
		test.name();
		test.oraganization();
		test.goal();
		test.months();
		test.budget();
		test.mail();
		test.phone();
		test.click();
		test.msg();
		
//		String SuccessMSG = driver.findElement(By.xpath("//img[@title=\"Success\"]")).getText();
//		System.out.println(SuccessMSG);
		
		Thread.sleep(5000);
		driver.quit();
	}
}
