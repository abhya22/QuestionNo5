package Assignment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class stoodeocontact {

	@FindBy(xpath="//span[text()=\"Contact\"]") private WebElement contact;
	@FindBy(xpath="//input[@name=\"name\"]") private WebElement name;
	@FindBy(xpath="//input[@name=\"organization\"]") private WebElement oraganization;
	@FindBy(xpath="//select[@name=\"completion\"]") private WebElement months;
	@FindBy(xpath="//select[@name=\"budget\"]") private WebElement budget;
	@FindBy(xpath="//input[@name=\"goals\"]") private WebElement goal;
	@FindBy(xpath="//input[@name=\"email\"]") private WebElement mail;
	@FindBy(xpath="//input[@name=\"phone\"]") private WebElement phone;
	@FindBy(xpath="//a[@class=\"link link-animation send\"]") private WebElement click;
	@FindBy(xpath="//p[@class=\"success\"]") private WebElement SuccessMSG;
	
	
	public stoodeocontact(WebDriver driver) {
		
		PageFactory.initElements(driver, this);
	}
	
	public void contact() {
		contact.click();
	}
	public void name() {
		name.sendKeys("ABC");
	}
	
	public void oraganization() {
		oraganization.sendKeys("XYZ");
	}
	
	public void months() {
		Select a = new Select(months);
		a.selectByValue("2-4 weeks");
	}
	
	public void budget() {
		Select a = new Select(budget);
		a.selectByValue("$3,450");
	}
	
	public void goal() {
		goal.sendKeys("IJK");
	}
	
	public void mail() {
		mail.sendKeys("ABC@gmail.com");
	}
	
	public void phone() {
		phone.sendKeys("8888888888");
		
	}
	
	public void click() {
		click.click();
	}
	
	public void msg() {
		String sm = SuccessMSG.getText();
		System.out.println(sm);
	} 
}
